import MultipleSelect from './MultipleSelect'

new MultipleSelect('#select-language')

new MultipleSelect('#select-multiple-language', {
  placeholder: 'Select language'
})